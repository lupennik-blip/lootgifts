LOOTGIFTS Mini App — visual demo

This is a responsive front-end prototype inspired by the uploaded LOOTGIFTS reference image.

Included:
- Mobile-first dark navy interface with blue gradients
- Case catalog and case details
- Case contents cards
- Demo-open button that adds a fixed-sequence item to the inventory
- Inventory navigation
- Bottom navigation: Cases / Upgrade / Contract / Contest / Items

Important:
- Demo only: no payment, real Telegram Stars, real gift delivery, or paid randomized reward mechanics.
- To turn this into a Telegram Mini App, host index.html on HTTPS and configure a Telegram bot's Web App button with that URL using BotFather or the Bot API. A production Telegram Mini App requires server-side Telegram initData validation before using user identity.
